package com.company;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        char[][] sopa = leeSopaLetras("sopamal.txt");
        escribeArrayBi(sopa);
    }

    private static char[][] leeSopaLetras(String fichero)
    {
        List<String> lineas = new ArrayList<>();
        String linea;
        int i, j, filas, columnas;
        boolean ok = true;
        char[][] sopa;

        try
        {
            FileReader fr = new FileReader(fichero);
            BufferedReader br = new BufferedReader(fr);

            linea = br.readLine();
            while (linea != null)
            {
                lineas.add(linea);
                linea = br.readLine();
            }

            br.close();
            fr.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        filas = lineas.size();
        columnas = lineas.get(0).length();

        for (i = 1; i < lineas.size(); i++)
        {
            if (lineas.get(i).length() != columnas)
            {
                ok = false;
                i = lineas.size();
            }
        }

        if(ok)
        {
            sopa = new char[filas][columnas];

            for(i = 0; i < filas; i++)
            {
                for(j = 0; j < columnas; j++)
                {
                    sopa[i][j] = lineas.get(i).charAt(j);
                }
            }
        }
        else
        {
            sopa = new char[0][0];
        }

        return sopa;
    }

    private static void escribeArrayBi(char[][] sopa)
    {
        int i;
        for(i=0;i<sopa.length;i++)
        {
            System.out.println(Arrays.toString(sopa[i]));
        }
    }
}
