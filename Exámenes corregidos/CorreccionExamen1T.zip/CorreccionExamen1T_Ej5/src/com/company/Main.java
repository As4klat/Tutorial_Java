package com.company;

public class Main
{

    public static void main(String[] args)
    {
        int[] a = {4, 7, 3, 1, 5};
        graficaBarras(a);
    }

    public static void graficaBarras(int[] a)
    {
        int i, j, max;
        boolean bien = true;

        for(i = 0; i < a.length; i++)
        {
            if(a[i] < 0 || a[i] > 9)
            {
                bien = false;
                i = a.length;
            }
        }

        if(bien)
        {
            max = maxArray(a);

            for(i = max; i > 0; i--)
            {
                for(j = 0; j < a.length; j++)
                {
                    if(a[j] >= i)
                    {
                        System.out.print("█ ");
                    }
                    else
                    {
                        System.out.print("  ");
                    }
                }
                System.out.println();
            }

            for(j = 0; j < a.length; j++)
            {
                System.out.print(a[j] + " ");
            }
            System.out.println();
        }
        else
        {
            System.out.println("Los valores tienen que estar entre 0 y 9");
        }
    }

    private static int maxArray(int[] a)
    {
        int max = a[0];
        int i;

        for(i=1;i<a.length;i++)
        {
            if(a[i] > max)
            {
                max = a[i];
            }
        }

        return max;
    }
}
