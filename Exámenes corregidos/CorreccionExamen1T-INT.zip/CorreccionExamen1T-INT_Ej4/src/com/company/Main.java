package com.company;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n, cifras;

        System.out.println("Dime un número");
        n = sc.nextInt();

        System.out.println("Tiene " + numeroCifras(n) + " cifras");
    }

    public static int numeroCifras(int n)
    {
        int cont;

        if(n == 0)
        {
            cont = 1;
        }
        else
        {
            if(n < 0)
            {
                n = -n; // n = Math.abs(n), n = n * -1;
            }

            cont = 0;
            while (n > 0)
            {
                n = n / 10;
                cont++;
            }
        }

        return cont;
    }
}
