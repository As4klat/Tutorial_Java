package com.company;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n, i, cuadrado;

        System.out.println("Dime un número");
        n = sc.nextInt();

        i = 1;
        cuadrado = 1;

        while(cuadrado < n)
        {
            i = i + 1;
            cuadrado = i * i;
        }

        if(cuadrado == n)
        {
            System.out.println("La raíz cuadrada es " + i);
        }
        else
        {
            i = i - 1;
            System.out.println("La raíz cuadrada es " + i + " y pico");
        }
    }
}
