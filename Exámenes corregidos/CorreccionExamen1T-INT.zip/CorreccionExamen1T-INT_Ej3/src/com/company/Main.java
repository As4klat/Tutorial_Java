package com.company;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        int segundos = leeHoraSegundos();

        System.out.println("Los segundos son: " + segundos);
    }

    public static int leeHoraSegundos()
    {
        int horas, minutos, segundos, segundosTotales;

        horas = leeHoras();
        minutos = leeMinutos();
        segundos = leeSegundos();

        segundosTotales = horaASegundos(horas, minutos, segundos);

        return segundosTotales;
    }

    public static int horaASegundos(int horas, int minutos, int segundos)
    {
        int segundosTotales;

        segundosTotales = (horas * 60 * 60) + (minutos * 60) + segundos;

        return segundosTotales;
    }

    public static int leeHoras()
    {
        Scanner sc = new Scanner(System.in);
        int horas;

        System.out.println("Dime las horas");
        horas = sc.nextInt();

        while(horas < 0 || horas > 23)
        {
            System.out.println("Las horas tienen que estar en 0 y 23");
            horas = sc.nextInt();
        }

        return horas;
    }

    public static int leeMinutos()
    {
        Scanner sc = new Scanner(System.in);
        int minutos;

        System.out.println("Dime los minutos");
        minutos = sc.nextInt();

        while(minutos < 0 || minutos > 59)
        {
            System.out.println("Los minutos tienen que estar en 0 y 59");
            minutos = sc.nextInt();
        }

        return minutos;
    }

    public static int leeSegundos()
    {
        Scanner sc = new Scanner(System.in);
        int segundos;

        System.out.println("Dime los minutos");
        segundos = sc.nextInt();

        while(segundos < 0 || segundos > 59)
        {
            System.out.println("Los segundos tienen que estar en 0 y 59");
            segundos = sc.nextInt();
        }

        return segundos;
    }
}
