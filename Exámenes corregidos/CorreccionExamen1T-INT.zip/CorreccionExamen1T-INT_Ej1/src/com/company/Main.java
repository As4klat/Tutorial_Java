package com.company;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int a, b, i;

        System.out.println("Dime el primer número impar");
        a = sc.nextInt();

        while (a % 2 == 0)
        {
            System.out.println("El número tiene que ser impar, escríbelo de nuevo");
            a = sc.nextInt();
        }

        System.out.println("Dime el segundo número impar (mayor que el primero)");
        b = sc.nextInt();

        while (b % 2 == 0 || b <= a)
        {
            System.out.println("El número tiene que ser impar y mayor que el primero, escríbelo de nuevo");
            b = sc.nextInt();
        }

        for (i = a; i <= b; i = i + 2)
        {
            System.out.print(i + " ");
        }
        System.out.println();

        for(i = b; i >= a; i = i - 2)
        {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
