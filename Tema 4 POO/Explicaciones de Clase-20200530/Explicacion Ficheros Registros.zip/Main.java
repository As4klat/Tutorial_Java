package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        CuentaBanco cb = new CuentaBanco();
        cb.numeroCuenta = "ES9800210001980000387439";
        cb.propietario = "Antonio García Rodríguez";
        cb.saldo = 14.5;
        cb.bloqueada = false;

        List<CuentaBanco> lista = new ArrayList<>();

        lista.add(cb);
    }
}

