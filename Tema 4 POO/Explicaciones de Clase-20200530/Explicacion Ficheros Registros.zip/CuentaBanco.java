package com.company;

public class CuentaBanco
{
    public String numeroCuenta;
    public String propietario;
    public double saldo;
    public boolean bloqueada;
}


