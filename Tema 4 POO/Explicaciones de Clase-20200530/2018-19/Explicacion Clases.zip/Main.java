package com.company;

public class Main
{

    public static void main(String[] args)
    {
//        Coche c = new Coche();
//
//        c.matricula = "1234FTP";
//        c.marca = "Nissan";
//        c.modelo = "Almera";
//        c.caballos = 110;
//        c.precio = 18000;
//        c.automatico = false;

        Coche c = new Coche("5324CCC", "Nissan", "Almera", 110, 18000, true);

        c.imprimeDatos();
    }
}
