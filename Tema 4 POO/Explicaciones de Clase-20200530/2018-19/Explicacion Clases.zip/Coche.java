package com.company;

import java.security.InvalidParameterException;

public class Coche
{
    // Atributos = variables
    private String matricula;
    private String marca;
    private String modelo;
    private int caballos;
    private double precio;
    private boolean automatico;

    // Constructor
    public Coche(String matricula, String marca, String modelo,
                 int caballos, double precio)
    {
        this.setMatricula(matricula);
        this.setMarca(marca);
        this.setModelo(modelo);
        this.setCaballos(caballos);
        this.setPrecio(precio);
        this.setAutomatico(false);
    }

    public Coche(String matricula, String marca, String modelo,
                 int caballos, double precio, boolean automatico)
    {
        this(matricula, marca, modelo, caballos, precio);

        this.setAutomatico(automatico);
    }

    // Métodos
    public void imprimeDatos()
    {
        System.out.println("Matricula:  " + getMatricula());
        System.out.println("Marca:      " + marca);
        System.out.println("Modelo:     " + getModelo());
        System.out.println("Caballos:   " + getCaballos());
        System.out.println("Precio:     " + getPrecio());
        System.out.println("Automático: " + isAutomatico());
    }

    // Propiedad
    public String getMatricula()
    {
        return matricula;
    }

    public void setMatricula(String matricula)
    {
        if(matricula.length() == 7)
        {
            this.matricula = matricula;
        }
        else
        {
            throw new InvalidParameterException("La matrícula debe tener 7 caracteres");
        }
    }

    public String getMarca()
    {
        return this.marca;
    }

    public void setMarca(String marca)
    {
        if(marca.length() > 0)
        {
            this.marca = marca;
        }
        else
        {
            throw new InvalidParameterException("La marca no puede estar vacía");
        }
    }

    public String getModelo()
    {
        return modelo;
    }

    public void setModelo(String modelo)
    {
        if(modelo.length() > 0)
        {
            this.modelo = modelo;
        }
        else
        {
            throw new InvalidParameterException("El modelo no puede estar vacío");
        }
    }

    public int getCaballos()
    {
        return caballos;
    }

    public void setCaballos(int caballos)
    {
        if(caballos >= 2)
        {
            this.caballos = caballos;
        }
        else
        {
            throw new InvalidParameterException("El coche tiene que tener más caballos");
        }
    }

    public double getPrecio()
    {
        return precio;
    }

    public void setPrecio(double precio)
    {
        if(precio >= 0)
        {
            this.precio = precio;
        }
        else
        {
            throw new InvalidParameterException("El coche no puede tener valor negativo");
        }
    }

    public boolean isAutomatico()
    {
        return automatico;
    }

    public void setAutomatico(boolean automatico)
    {
        this.automatico = automatico;
    }
}
