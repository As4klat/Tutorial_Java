package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Prueba
{
    private static Random r = new Random();
    public int valor;
    public static int valorStatic;
    public static List<Integer> lista = new ArrayList<>();

    static
    {
        lista.add(1);
        lista.add(2);
        lista.add(3);
        lista.add(4);
        lista.add(5);
    }

    public void setStatic(int nuevoValor)
    {
        valorStatic = nuevoValor;
    }

    public int getStatic()
    {
        return valorStatic;
    }

    public static int generaRandom()
    {
        return r.nextInt(100) + 1;
    }


//    public static int getValor()
//    {
//        //return this.valor;
//    }


}
