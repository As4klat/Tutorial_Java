package com.company;

public class Main
{
    public static void funcion()
    {

    }

    public static void main(String[] args)
    {
        Prueba p = new Prueba();
        Prueba p2 = new Prueba();
        p.valor = 4;
        p.setStatic(4);

        p2.valor = 6;
        p2.setStatic(6);



        //System.out.println(p.getStatic() +"\n" + p2.getStatic());
        System.out.println(p.generaRandom() + "\n" + p2.generaRandom());

        System.out.println(Prueba.generaRandom());

        funcion();

        System.out.println(Prueba.lista);

    }
}
