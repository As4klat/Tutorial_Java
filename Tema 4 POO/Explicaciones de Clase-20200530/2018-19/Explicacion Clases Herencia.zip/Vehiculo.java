package com.company;

public abstract class Vehiculo
{
    protected String matricula;
    protected int caballos;
    protected boolean electrico;

    public Vehiculo() {}

    public Vehiculo(String matricula, int caballos, boolean electrico)
    {
        this.matricula = matricula;
        this.caballos = caballos;
        this.electrico = electrico;
    }

    // Método abstracto = obliga a los hijos a implementarlo
    public abstract String toString();
}
