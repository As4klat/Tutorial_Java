package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main
{

    public static void main(String[] args)
    {
        //Vehiculo v = new Vehiculo("1234BBB", 90, false);
        Coche c = new Coche("8798CCC", 110, false, 4, 5);
        Moto m = new Moto("9875DDD", 75, false, true);

        List<Vehiculo> lista = new ArrayList<>();
        //lista.add(v);
        lista.add(c);
        lista.add(m);

        for(int i = 0; i < lista.size(); i++)
        {
            // Para ver si un objeto es de una clase u otra
            if(lista.get(i) instanceof Moto)
            {
                System.out.println("Es una moto");
            }
            else
            {
                if(lista.get(i) instanceof Coche)
                {
                    System.out.println("Es un coche");
                }
            }

            System.out.println(lista.get(i).toString());
        }
    }
}
