package com.company;

public class Moto extends Vehiculo
{
    private boolean tieneSidecar;

    public Moto(String matricula, int caballos, boolean electrico,
                boolean tieneSidecar)
    {
        // Para llamar al constructor de la clase padre
        super(matricula, caballos, electrico);

        this.tieneSidecar = tieneSidecar;
    }

    public String toString()
    {
        return "Matricula: " + this.matricula + ", Caballos: " + this.caballos +
                ", Electrico: " + this.electrico + ", Sidecar: " +
                this.tieneSidecar;
    }

}
