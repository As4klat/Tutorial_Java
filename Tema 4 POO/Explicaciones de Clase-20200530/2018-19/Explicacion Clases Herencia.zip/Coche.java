package com.company;

public class Coche extends Vehiculo
{
    private int numeroPlazas;
    private int numeroPuertas;

    public Coche(String matricula, int caballos, boolean electrico,
                 int numeroPlazas, int numeroPuertas)
    {
        this.matricula = matricula;
        this.caballos = caballos;
        this.electrico = electrico;
        this.numeroPlazas = numeroPlazas;
        this.numeroPuertas = numeroPuertas;
    }

    public String toString()
    {
        return "Matricula: " + this.matricula + ", Caballos: " + this.caballos +
                ", Electrico: " + this.electrico + ", Plazas: " +
                this.numeroPlazas + ", Puertas: " + this.numeroPuertas;
    }
}
