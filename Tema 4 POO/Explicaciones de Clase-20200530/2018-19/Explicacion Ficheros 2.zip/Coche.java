package com.company;

public class Coche
{
    public String matricula;
    public String marca;
    public String modelo;
    public int caballos;
}
