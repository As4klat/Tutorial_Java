package com.company;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        Coche c = new Coche();

        c.matricula = "1234BCD";
        c.marca = "SEAT";
        c.modelo = "Panda";
        c.caballos = 55;

        List<Coche> lista = new ArrayList<>();

        lista.add(c);

        if(Files.exists(Paths.get("fichero.txt")))
        {

        }

//        Files.delete();
//        Files.copy();
//        Files.move(Paths.get("fichero1.txt"), Paths.get("C:\\Windows"));

        int i;
        File dir = new File("C:\\");
        File[] listado = dir.listFiles();

        for(i = 0; i < listado.length; i++)
        {
            if(listado[i].isFile())
            {
                System.out.println(listado[i].getName() + " - " + listado[i].length());
            }
        }

        try
        {
            Files.createDirectories(Paths.get("D:\\prueba\\prueba2\\prueba3"));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }


    }
}

